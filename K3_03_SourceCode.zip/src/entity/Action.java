package entity;

public interface Action {
    public void action();
    public void actionStop();
}
