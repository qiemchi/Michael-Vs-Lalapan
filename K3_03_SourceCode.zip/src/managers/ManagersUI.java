package managers;

import java.awt.Graphics;

public interface ManagersUI {
    public void update();
    public void draw(Graphics g);
}
