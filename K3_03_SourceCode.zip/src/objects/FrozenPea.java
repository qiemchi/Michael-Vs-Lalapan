package objects;

public class FrozenPea extends Pea {

    public FrozenPea(int x, int y) {
        super(x, y, "Frozen");
    }

}
