package objects;

public class NormalPea extends Pea{
    
    public NormalPea(int x, int y) {
        super(x, y, "Normal");
    }
}
